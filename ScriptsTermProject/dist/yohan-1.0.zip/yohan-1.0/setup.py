# -*- coding: utf-8 -*-
from distutils.core import setup

setup(name ='yohan',version='1.0', py_modules = ['main','DaumOpenAPI','testEmail'],author_email = "dygks910910@daum.net")